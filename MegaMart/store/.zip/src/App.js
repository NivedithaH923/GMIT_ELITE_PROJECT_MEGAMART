import React from 'react';
import './App.css';
import Header from './component/Header/Header';
import Banner from './component/Banner/Banner'; // Import the Banner component
import Categories from './component/Categories/Categories';
import Footer from './component/Footer/Footer';

function App() {
  return (
    <div className="App">
      <Header />
      <Banner /> {/* Add Banner below the Header */}
      <h1 className="center-text">categories</h1> {/* Centered H1 */}
      <Categories /> {/* Category section */}
      
      <img
            src="images/megasale.jpg"
            alt="MegaSale"
            className="mega-sale"
          />
      <Footer />
    </div>
  );
}

export default App;
