import React from 'react';
import './Header.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faShoppingCart, faSearch } from '@fortawesome/free-solid-svg-icons';

const Header = () => {
  return (
    <header className="header">
      {/* Website name at the left */}
      <div className="logo">MegaMart</div>

      {/* Search bar at the center with Search Icon */}
      <div className="search-bar">
        <FontAwesomeIcon icon={faSearch} className="search-icon" />
        <input
          type="text"
          placeholder="Search for products..."
          className="search-input"
        />
      </div>

      {/* Login and Cart with icons and labels below */}
      <div className="right-section">
        <div className="icon-with-label">
          <FontAwesomeIcon icon={faShoppingCart} className="icon" />
          <span className="label">Cart</span>
        </div>
        <div className="icon-with-label">
          <FontAwesomeIcon icon={faUser} className="icon" />
          <span className="label">Login</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
