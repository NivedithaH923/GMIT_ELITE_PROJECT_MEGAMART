// Categories.js
import React from 'react';
import './Categories.css'; // CSS for styling the category section

const Categories = () => {
  const categories = [
    { name: 'Ladier wear', image: '/images/ladieswear.jpg' },
    { name: 'Mens wear', image: '/images/Menswear.jpg' },
    { name: 'Home Appliances', image: '/images/Homeappliances.jpg' },
  ];

  return (
    <div className="categories-container">
      {categories.map((category, index) => (
        <div className="category-box" key={index}>
          <img src={category.image} alt={category.name} className="category-img" />
          <div className="category-name">{category.name}</div>
        </div>
      ))}
    </div>
  );
};

export default Categories;
